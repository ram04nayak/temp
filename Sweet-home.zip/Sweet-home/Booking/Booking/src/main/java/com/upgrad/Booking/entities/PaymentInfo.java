package com.upgrad.Booking.entities;

public class PaymentInfo {
    private PaymentMode paymentMode;
    private Integer bookingId;
    private float roomPrice;
    private String transactionId;


    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public Integer getBookedOn() {
        return bookingId;
    }

    public void setBookedOn(Integer bookedId) {
        this.bookingId = bookedId;
    }

    public float getRoomPrice() {
        return roomPrice;
    }

    public void setRoomPrice(float roomPrice) {
        this.roomPrice = roomPrice;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }
}
