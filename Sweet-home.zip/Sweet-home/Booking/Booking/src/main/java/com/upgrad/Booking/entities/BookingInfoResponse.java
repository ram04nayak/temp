 package com.upgrad.Booking.entities;

 import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

import static com.upgrad.Booking.Constants.BookingConstants.Room_Price_each;


 public class BookingInfoResponse {

        private int bookingId;
        private LocalDate fromDate;
        private LocalDate toDate;
        private String aadharNumber;
        private int numOfRooms;
        private String roomNumbers;
        private int roomPrice;
        private String transactionId="0";
        private LocalDate createdOn;

        public BookingInfoResponse(){}

     public BookingInfoResponse(int bookingId, LocalDate fromDate, LocalDate toDate, String aadharNumber, int numOfRooms,
                                String roomNumbers, int roomPrice, String transactionId, LocalDate bookedOn) {
         this.bookingId = bookingId;
         this.fromDate = fromDate;
         this.toDate = toDate;
         this.aadharNumber = aadharNumber;
         this.numOfRooms = numOfRooms;
         this.roomNumbers = roomNumbers;
         this.roomPrice = roomPrice;
         this.transactionId = transactionId;
         this.createdOn = bookedOn;
     }

     public int getBookingId(int id) {
            return bookingId;
        }

        public void setBookingId(int bookingId) {
            this.bookingId = bookingId;
        }

        public LocalDate getFromDate() {
            return fromDate;
        }

        public void setFromDate(LocalDate fromDate) {
            this.fromDate = fromDate;
        }

        public LocalDate getToDate() {
            return toDate;
        }

        public void setToDate(LocalDate toDate) {
            this.toDate = toDate;
        }

        public String getAadharNumber() {
            return aadharNumber;
        }

        public void setAadharNumber(String aadharNumber) {
            this.aadharNumber = aadharNumber;
        }

        public int getNumOfRooms() {
            return numOfRooms;
        }

        public void setNumOfRooms(int numOfRooms) {
            this.numOfRooms = numOfRooms;
        }


     public  static String getRoomNumbers(int count){
         Random rand = new Random();
         int upperBound = 100;
         ArrayList<String>numberList = new ArrayList<String>();

         for (int i=0; i<count; i++){
             numberList.add(String.valueOf(rand.nextInt(upperBound)));
         }
         String listString = "";

         for (String s : numberList)
         {
             listString += s + ",";
         }

         return listString.substring(0, listString.length() - 1) ;
     }

     public void setTransactionalId(String transactionalId) {
         this.transactionId = transactionalId;
     }

     public String getTransactionalId() {
         return transactionId;
     }

     public void setRoomNumbers(String roomNumbers) {
         this.roomNumbers = roomNumbers;
     }

        public int getRoomPrice(int numOfRooms) {
          int roomprice=Room_Price_each*numOfRooms;
          return roomPrice;
        }

        public LocalDate getBookedOn() {
            return createdOn;
        }

        public void setBookedOn(LocalDate bookedOn) {
            this.createdOn = bookedOn;
        }

        public BookingInfoEntity getBookingInfo()
        { return new BookingInfoEntity(fromDate,toDate,aadharNumber,numOfRooms);}

        @Override
        public String toString() {
            return "BookingInfoEntity{" +
                    "bookingId=" + bookingId +
                    ", fromDate=" + fromDate +
                    ", toDate=" + toDate +
                    ", aadharNumber='" + aadharNumber + '\'' +
                    ", numOfRooms=" + numOfRooms +
                    ", roomNumbers='" + roomNumbers + '\'' +
                    // ", roomPrice=" + roomPrice +
                    ", transactionId=" + transactionId +
                    ", bookedOn=" + createdOn +
                    '}';
        }


    }


