package com.upgrad.Booking.entities;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.RecordMetadata;

import java.time.LocalDate;
import java.util.Objects;

public class BookingInfo_MSG implements Callback {

    private Integer Id;
    private LocalDate fromdate;
    private LocalDate toDate;
    private String aadharum;

    public BookingInfo_MSG(Integer id, LocalDate fromdate, LocalDate toDate, String aadharum) {
        Id = id;
        this.fromdate = fromdate;
        this.toDate = toDate;
        this.aadharum = aadharum;
    }

    public BookingInfo_MSG() {
        super();
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public LocalDate getFromdate() {
        return fromdate;
    }

    public void setFromdate(LocalDate fromdate) {
        this.fromdate = fromdate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public String getAadharum() {
        return aadharum;
    }

    public void setAadharum(String aadharum) {
        this.aadharum = aadharum;
    }

    @Override
    public String toString() {
        return "BookingInfo_MSG{" +
                "Id=" + Id +
                ", fromdate=" + fromdate +
                ", toDate=" + toDate +
                ", aadharum='" + aadharum + '\'' +
                '}';
    }
   @Override
    public boolean equals(Object o){
        if(this==o){ return true; }
        if (o==null || getClass()!=o.getClass()) {return true;}

        BookingInfo_MSG that=(BookingInfo_MSG) o;
        return Objects.equals(Id,that.Id)
                && Objects.equals(aadharum,that.aadharum)
                &&Objects.equals(fromdate,that.fromdate)
                &&Objects.equals(toDate,that.toDate);
    }
    @Override
    public int hashCode(){
        return Objects.hash(Id,aadharum,fromdate,toDate);
    }

    @Override
    public void onCompletion(RecordMetadata recordMetadata, Exception e) {


    }
}
