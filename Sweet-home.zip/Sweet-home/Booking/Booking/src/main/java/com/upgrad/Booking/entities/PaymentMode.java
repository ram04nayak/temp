package com.upgrad.Booking.entities;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PaymentMode {
    UPI("upi"), CARD("card");
    private String option;

    private PaymentMode(String optio) {
        this.option = optio;
    }

    @JsonValue
    public String getOption() {
        return this.option;
    }

    @Override
    public String toString() {
        return "PaymentMode{" +
                "option='" + option + '\'' +
                '}';
    }

    @JsonCreator
    public static PaymentMode option(String option) throws Error {
        for (PaymentMode mode : PaymentMode.values()) {
            try {
                if (mode.getOption().equals(option)) {
                    return mode;
                }
            } catch (Exception e) {
                Error error = new Error("400", "Invalid mode of Payment");
                throw error;
            }
        }
        return null;
    }
}
