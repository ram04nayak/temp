package com.upgrad.Booking.entities;

public class Error extends Throwable {
    private String errorCode;
    private String errorMessage;

    public Error(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public Error Error() {
        return new Error("400","Booking Id Not Found");
    }
}
