package com.upgrad.Booking.services;

import com.upgrad.Booking.Exception.BookingFailedException;
import com.upgrad.Booking.FeignClient.PaymentServiceClient;
import com.upgrad.Booking.dao.BookingDao;
import com.upgrad.Booking.entities.BookingInfoEntity;
import com.upgrad.Booking.entities.BookingInfoResponse;
import com.upgrad.Booking.entities.PaymentInfo;
import com.upgrad.Booking.entities.PaymentResponse;
import com.upgrad.Booking.producer.kafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

import static com.upgrad.Booking.Constants.BookingConstants.payment_service_url;

@Service
public class BookingServiceImpl implements BookingService {

    PaymentServiceClient paymentServiceClient;
    @Autowired
    private BookingDao bookingDao;
    private RestTemplate restTemplate;

    @Autowired
    KafkaTemplate<String, String> kafkaTemplate;

    @Autowired
    public BookingServiceImpl(BookingDao bookingDao, RestTemplate restTemplate,
                              KafkaTemplate<String, String> kafkaTemplate) {
        this.bookingDao = bookingDao;
        this.restTemplate = restTemplate;
        this.kafkaTemplate = kafkaTemplate;
    }

  @Autowired
  kafkaProducer kafkaProducer;


    public void produceMessage(Integer id, LocalDate fromdate, LocalDate toDate, String aadharum)
            throws IOException {
        kafkaProducer.publish(id, fromdate, toDate, aadharum);
    }

    //BookingDaoImpl bookingDao;
//    @Override
//    public BookingInfoEntity createBooking(BookingInfoResponse roomBookingRequest) throws BookingFailedException {
//        BookingInfoEntity bookingInfo = roomBookingRequest.getBookingInfo();
//        ArrayList<Integer> roomNumbers = roomBookingRequest.getRoomNumbers(bookingInfo.getNumOfRooms());
//        bookingInfo.setRoomNumbers(roomNumbers);
//        bookingInfo.setRoomPrice(100);
//        //bookingInfo.setTransactionalId("123");
//        return bookingDao.save(bookingInfo);
//    }

    @Override
     public BookingInfoEntity createBooking(BookingInfoResponse roomBookingRequest) throws BookingFailedException {
            BookingInfoEntity bookingInfo = roomBookingRequest.getBookingInfo();
            bookingInfo.setFromDate(roomBookingRequest.getFromDate());
            bookingInfo.setToDate(roomBookingRequest.getToDate());
            bookingInfo.setAadharNumber(roomBookingRequest.getAadharNumber());
            bookingInfo.setNumOfRooms(roomBookingRequest.getNumOfRooms());
            bookingInfo.setRoomNumbers(roomBookingRequest.getRoomNumbers(roomBookingRequest.getNumOfRooms()));
            bookingInfo.setTransactionId(roomBookingRequest.getTransactionalId());
            return bookingDao.save(bookingInfo);
        }

    public  static String getRoomNumbers(int count){
        Random rand = new Random();
        int upperBound = 100;
        ArrayList<String>numberList = new ArrayList<String>();

        for (int i=0; i<count; i++){
            numberList.add(String.valueOf(rand.nextInt(upperBound)));
        }
        String listString = "";

        for (String s : numberList)
        {
            listString += s + ",";
        }

        return listString.substring(0, listString.length() - 1) ;
    }

    @Override
    public BookingInfoEntity acceptBookingDetails(BookingInfoEntity bookingInfoEntities) {
        return bookingDao.save(bookingInfoEntities);
    }

    @Transactional
    @Override
    public List<BookingInfoEntity> acceptMultipleBookingDetails(List<BookingInfoEntity> bookingInfoEntities) {
        List<BookingInfoEntity> bookigs = new ArrayList<>();
        for (BookingInfoEntity bookingInfoEntity1 : bookingInfoEntities) {
            bookigs.add(acceptBookingDetails(bookingInfoEntity1));
        }
        return bookigs;
    }

    @Override
    public BookingInfoEntity getBookingDetails(int id) {
        return bookingDao.findById(id).get();
    }

    @Override
    public BookingInfoEntity updateBookingDetails(int id, BookingInfoEntity bookingInfoEntity) {
        BookingInfoEntity savedbooking = getBookingDetails(id);

        savedbooking.setFromDate(bookingInfoEntity.getFromDate());
        savedbooking.setToDate(bookingInfoEntity.getToDate());
        savedbooking.setAadharNumber(bookingInfoEntity.getAadharNumber());
        savedbooking.setNumOfRooms(bookingInfoEntity.getNumOfRooms());
        bookingDao.save(savedbooking);
        return savedbooking;
    }

    @Override
    public boolean deleteBookingDetails(int id) {
        BookingInfoEntity savedbooking = getBookingDetails(id);
        if (savedbooking == null) {
            return false;
        }
        bookingDao.delete(savedbooking);
        return true;
    }

    @Override
    public List<BookingInfoEntity> getAllBooking() {
        return bookingDao.findAll();
    }

    @Override
    public Page<BookingInfoEntity> getPaginatedBookingDetails(Pageable pageable) {
        return bookingDao.findAll(pageable);
    }

        @Override
        public BookingInfoEntity proceedpayment ( int id, PaymentInfo paymentInfo) throws
        com.upgrad.Booking.entities.Error {
            String transactionId;
            Optional<BookingInfoEntity> bookingInfo = bookingDao.findById(id);
            if (bookingInfo.isPresent()) {
                BookingInfoEntity bookingInfoEntity = bookingInfo.get();
                PaymentResponse paymentResponse = new PaymentResponse(id, paymentInfo);
                transactionId = restTemplate.postForObject(payment_service_url, paymentResponse, Integer.class).toString();
                System.out.println(transactionId);
                bookingInfoEntity.setTransactionId(transactionId);
                bookingDao.save(bookingInfoEntity);
//                BookingInfo_MSG msg = new BookingInfo_MSG(bookingInfoEntity.getBookingId(),
//                        bookingInfoEntity.getFromDate(), bookingInfoEntity.getToDate(),
//                        bookingInfoEntity.getAadharNumber());
                String Message = "Booking confirmed for user with aadhaar number: " +
                        bookingInfoEntity.getAadharNumber() + "    |    " +
                        "Here are the booking details:    " +
                        bookingInfoEntity.toString();
                kafkaTemplate.send("MSG", Message);
                return bookingInfoEntity;
            } else {
                com.upgrad.Booking.entities.Error error = new com.upgrad.Booking.entities.
                        Error("400", "Invalid Booking Id");
                throw error;
            }
        }


    }