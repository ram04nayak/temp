package com.upgrad.Booking.Constants;

public interface BookingConstants {
    String PAYMENT_SUCCESS = "PAYMENT_SUCCESS";
    String BOOKING_CREATED = "BOOKING_DONE";
    String BOOKING_FAILED = "BOOKING_FAILED";
    String PAYMENT_FAILED_ERROR_CODE = "EPG001";
    Integer Room_Price_each=1000;
    String payment_service_url="http://localhost:8083/payment";
}
