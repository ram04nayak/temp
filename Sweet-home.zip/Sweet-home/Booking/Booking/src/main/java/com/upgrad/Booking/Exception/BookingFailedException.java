package com.upgrad.Booking.Exception;

public class BookingFailedException extends Throwable{
}
