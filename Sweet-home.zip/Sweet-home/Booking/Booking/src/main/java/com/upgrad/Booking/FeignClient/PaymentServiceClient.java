package com.upgrad.Booking.FeignClient;

import com.upgrad.Booking.entities.PaymentInfo;
import com.upgrad.Booking.entities.PaymentResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


@FeignClient(name = "payment-client",url = "$payment_service_url}")
    public interface PaymentServiceClient {

    @PostMapping("/transaction/{transactionId}")
    @RequestMapping(value = "$payment_service_url}",method = RequestMethod.POST)
    public PaymentResponse getPaymentDetails(@PathVariable("id") int id, PaymentInfo paymentInfo);

}
