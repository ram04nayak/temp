package com.upgrad.paymentservice.controller;

import com.upgrad.paymentservice.entities.Error;
import com.upgrad.paymentservice.entities.PaymentRequest;
import com.upgrad.paymentservice.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PaymentController {

	@Autowired
	PaymentService paymentService;


	@Autowired
	public PaymentController(PaymentService paymentService) {
		super();
		this.paymentService = paymentService;
	}

	@GetMapping("/hello")
	public String sayHello()
	{
		System.out.println("Hi");
		return "Hello";
	}

	@PostMapping("/transaction")
	@ResponseStatus(code = HttpStatus.CREATED)
	public int getPaymentDetails(
			@RequestBody PaymentRequest paymentRequest) throws Error {
		return this.paymentService.getPaymentDetails(paymentRequest.getBookingId(),
												paymentRequest.getPaymentDetails());
	}

	@PostMapping("/transaction/{transactionId}")
	@ResponseStatus(code = HttpStatus.CREATED)
	public int getPaymentDetails(@PathVariable int transactionid,
								 @RequestBody PaymentRequest paymentRequest) throws Error {
		return this.paymentService.getPaymentDetails(paymentRequest.getBookingId(),
				paymentRequest.getPaymentDetails());
	}

	@GetMapping("/transaction/{transactionId}")
	public com.upgrad.paymentservice.entities.PaymentDetailsEntity
	getPaymentById(@PathVariable int paymentId) throws Exception, Error {
		return this.paymentService.getPaymentById(paymentId);
	}
}
